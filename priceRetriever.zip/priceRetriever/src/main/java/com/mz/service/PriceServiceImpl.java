package com.mz.service;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mz.config.JmsPublisher;
import com.mz.dao.IPriceDao;
import com.mz.vo.TradeInstrumentPrice;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
//All logging is done using Lombok 
@Service
@Transactional
@Setter @Getter
public class PriceServiceImpl implements IPriceService {

	@Autowired
	private IPriceDao dao;

	@Autowired
	CacheManager cacheManagerForVendors;

	@Autowired
	CacheManager cacheManagerForIns;

	@Autowired
	JmsPublisher publisher;

	@Override
	@Cacheable(value = "vendors", key = "#vendorId")
	public Set<TradeInstrumentPrice> getPriceByVendor(String vendorId) {
		return dao.getPriceByVendor(vendorId);
	}

	@Override
	@Cacheable(value = "ins", key = "#instId")
	public Set<TradeInstrumentPrice> getPriceByInst(String instId) {
		return dao.getPriceByInst(instId);
	}

	@Override
	public void setInstrumentPrice(TradeInstrumentPrice ip) {
		dao.setInstrumentPrice(ip);
		updateCache(ip, cacheManagerForIns, "ins");
		updateCache(ip, cacheManagerForVendors, "vendors");
		// publish to topic
		publisher.publishToTopic(ip);
	}

	@SuppressWarnings("unchecked")
	private void updateCache(TradeInstrumentPrice price, CacheManager cacheManager, String cacheName) {
		Cache cache = cacheManager.getCache(cacheName);

		Cache.ValueWrapper tradeInstrumentCache;
		if (cacheName.equalsIgnoreCase("vendors")) {
			tradeInstrumentCache = cache.get(price.getVendorId());
		} else {
			tradeInstrumentCache = cache.get(price.getInstrumentId());
		}

		HashSet<TradeInstrumentPrice> set;
		if (tradeInstrumentCache != null) {
			set = (HashSet<TradeInstrumentPrice>) tradeInstrumentCache.get();
			set.add(price);
		} else {
			set = new HashSet<TradeInstrumentPrice>(Arrays.asList(price));
		}
		cacheManager.getCache(cacheName).put(price.getVendorId(), set);
		if (cacheName.equalsIgnoreCase("vendors")) {
			cacheManager.getCache(cacheName).put(price.getVendorId(), set);
		} else {
			cacheManager.getCache(cacheName).put(price.getInstrumentId(), set);
		}
	}

	/*
	 * Auto evict based on time
	 */
	@Override
	public void evictAllCaches() {

		// clear cache for vendors
		cacheManagerForVendors.getCacheNames().stream().forEach(c -> cacheManagerForVendors.getCache(c).clear());

		// clear cache for instruments
		cacheManagerForIns.getCacheNames().stream().forEach(c -> cacheManagerForIns.getCache(c).clear());

	}
}
