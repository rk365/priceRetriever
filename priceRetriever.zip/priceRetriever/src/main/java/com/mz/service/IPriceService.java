package com.mz.service;

import java.util.Set;

import org.springframework.stereotype.Service;

import com.mz.vo.TradeInstrumentPrice;

@Service
public interface IPriceService {
	
 Set<TradeInstrumentPrice> getPriceByVendor(String vendorId);	
 Set<TradeInstrumentPrice> getPriceByInst(String instId);	

 void setInstrumentPrice(TradeInstrumentPrice ip);
void evictAllCaches();

}
