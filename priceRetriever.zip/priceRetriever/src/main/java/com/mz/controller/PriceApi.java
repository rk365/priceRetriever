package com.mz.controller;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mz.service.IPriceService;
import com.mz.service.PriceServiceImpl;
import com.mz.vo.TradeInstrumentPrice;

@RestController
public class PriceApi {
	@Autowired
	private final PriceServiceImpl priceService = null;

	@PostMapping(value = "/instruments", produces = "application/json", consumes = "application/json")
    public ResponseEntity<?> createPrice(@RequestBody TradeInstrumentPrice newPriceRequest) {
        priceService.setInstrumentPrice(newPriceRequest);
        return ResponseEntity.accepted().build();
    }

    @GetMapping(value = "/vendor/{id}/prices", produces = "application/json")
    public Collection<TradeInstrumentPrice> getPriceByVendor(@PathVariable String id) {
        return priceService.getPriceByVendor(id);
    }

    @GetMapping(value = "/instrument/{id}/prices", produces = "application/json")
    public Collection<TradeInstrumentPrice> getByInstrument(@PathVariable String id) {
        return priceService.getPriceByInst(id);
    }
}