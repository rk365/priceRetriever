package com.mz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;

@SpringBootApplication
@ComponentScan(basePackages = "com.mz")
@PropertySource(value= {"classpath:application.properties"})
public class PriceRetrieverApplication {

	public static void main(String[] args) {
		SpringApplication.run(PriceRetrieverApplication.class, args);
	}

}
