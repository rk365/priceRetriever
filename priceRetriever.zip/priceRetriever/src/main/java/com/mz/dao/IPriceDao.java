package com.mz.dao;

import java.util.Set;

import org.springframework.stereotype.Component;

import com.mz.vo.TradeInstrumentPrice;

@Component
public interface IPriceDao {
	 Set<TradeInstrumentPrice> getPriceByVendor(String vendorId);	
	 Set<TradeInstrumentPrice> getPriceByInst(String instId);	

	 void setInstrumentPrice(TradeInstrumentPrice ip);
}
