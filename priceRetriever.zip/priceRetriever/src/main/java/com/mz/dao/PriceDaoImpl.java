package com.mz.dao;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.mz.vo.TradeInstrumentPrice;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class PriceDaoImpl implements IPriceDao{
	
	private final ConcurrentHashMap<TradeInstrumentPrice, TradeInstrumentPrice> prices = new ConcurrentHashMap<>();

	@Override
	public Set<TradeInstrumentPrice> getPriceByVendor(String vendorId) {
		
		return prices.values().stream()
				.filter(tip -> vendorId.equals(tip.getVendorId()))
				.collect(Collectors.toSet());
	}

	@Override
	public Set<TradeInstrumentPrice> getPriceByInst(String instId) {
		
		return prices.values().stream()
				.filter(tip -> instId.equals(tip.getInstrumentId()))
				.collect(Collectors.toSet());
	}

	@Override
	public void setInstrumentPrice(TradeInstrumentPrice ip) {
			prices.put(ip, ip);	
	}

}
