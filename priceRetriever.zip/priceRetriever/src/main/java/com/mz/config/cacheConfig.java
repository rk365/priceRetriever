package com.mz.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CachingConfigurerSupport;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import com.mz.service.IPriceService;

@Configuration
@EnableCaching
@EnableScheduling
public class cacheConfig extends CachingConfigurerSupport{
	
	@Autowired
	IPriceService ps;
	
	@Bean
	public CacheManager cacheManagerForIns() {
		return new ConcurrentMapCacheManager("ins");
	}
	
	@Bean
	public CacheManager cacheManagerForVendors() {
		return new ConcurrentMapCacheManager("vendors");
	}
	
	@Bean
	public CacheResolver cacheResolver() {
		return new CacheResolver(cacheManagerForVendors(), cacheManagerForIns());
	}
	
	@Scheduled(cron = "0 0 5 */30 * *")
//	@Scheduled(cron = "${cron.expression}")
	public void evictCache() {
		ps.evictAllCaches();
	}
}
