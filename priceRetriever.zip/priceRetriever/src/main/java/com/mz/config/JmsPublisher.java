package com.mz.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

import com.mz.vo.TradeInstrumentPrice;

import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Component
@EnableConfigurationProperties
@Slf4j
public class JmsPublisher {

	@Autowired
	private JmsTemplate jmsTemplate;
	
	@Value("topic") 
	@Setter
	private String topic;
	
	public void publishToTopic(TradeInstrumentPrice tip) {
		jmsTemplate.convertAndSend(topic, tip);
	}
	
	
	
}
