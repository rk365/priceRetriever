package com.mz.config;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.interceptor.CacheOperationInvocationContext;

public class CacheResolver implements org.springframework.cache.interceptor.CacheResolver{

	  private final CacheManager cacheManagerForVendors;
	    private final CacheManager cacheManagerForIns;    
	    private static final String V_CACHE = "vendors";    
	    private static final String I_CACHE = "ins";
	    
	    public CacheResolver(CacheManager vendorCacheManager,CacheManager insCacheManager) {
	        this.cacheManagerForVendors = vendorCacheManager;
	        this.cacheManagerForIns=insCacheManager;
	        
	    }

	    @Override
	    public Collection<? extends Cache> resolveCaches(CacheOperationInvocationContext<?> context) {
	        Collection<Cache> caches = new ArrayList<Cache>();
	        if ("getPriceByVendor".equals(context.getMethod().getName())) {
	            caches.add(cacheManagerForVendors.getCache(V_CACHE));
	        } else {
	            caches.add(cacheManagerForIns.getCache(I_CACHE));
	        }
	        return caches;
	    }
	}

