package com.mz.vo;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;

import lombok.*;
import java.io.Serializable;
@EqualsAndHashCode
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Setter @Getter
@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public class TradeInstrumentPrice implements Serializable {
	private static final long serialVersionUID = 1L;
	@JsonProperty("vendorId")private String vendorId;
	@JsonProperty("instrumentId")private String instrumentId;

	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class)
	@JsonProperty("priceDate")
	private LocalDate priceDate;
	
	@JsonProperty("price")private BigDecimal price;
}
