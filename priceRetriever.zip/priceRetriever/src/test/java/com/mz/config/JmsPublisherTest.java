package com.mz.config;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jms.core.JmsTemplate;

import com.mz.PriceRetrieverApplication;
import com.mz.service.PriceServiceImpl;
import com.mz.vo.TradeInstrumentPrice;

@SpringBootTest(classes = {PriceRetrieverApplication.class})
class JmsPublisherTest {
    @Autowired
    private PriceServiceImpl priceService;
    
    @Autowired
    private JmsTemplate jmsTemplate;
    TradeInstrumentPrice i4 = new TradeInstrumentPrice("v4", "i4", LocalDate.now().plusDays(10),new BigDecimal("2000"));

    
    @Test
    public void testPublishMessageToTopic() {
    	priceService.getPublisher().setTopic("topic-test");
        priceService.getPublisher().publishToTopic(i4);
        this.jmsTemplate.setReceiveTimeout(5000);
        TradeInstrumentPrice price = (TradeInstrumentPrice) this.jmsTemplate.receiveAndConvert("topic-test");
        assertTrue(i4.equals(price));
    }

}
