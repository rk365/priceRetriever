package com.mz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PriceRetrieverApplicationTests {

	@Test
	void contextLoads() {
	}

}
