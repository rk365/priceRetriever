package com.mz.exception;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
@RestController
public class CustomExceptionHandler extends ResponseEntityExceptionHandler{

	public final ResponseEntity<Object> handleAllExceptions(Exception e, WebRequest req) throws Exception
	{
		ExceptionResponse exResp = new ExceptionResponse(new Date(), e.getMessage(), req.getDescription(false));
		return new ResponseEntity(exResp, HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
