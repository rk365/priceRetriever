package com.mz.integrator;

import javax.jms.ConnectionFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.context.IntegrationContextUtils;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.Transformers;
import org.springframework.integration.jms.dsl.Jms;
import org.springframework.jms.support.converter.MessageConverter;
import org.springframework.messaging.MessagingException;

import com.mz.service.IPriceService;
import com.mz.vo.TradeInstrumentPrice;

@Configuration
public class IncomingMessageListener {

	@Autowired
	IPriceService service;

	@Bean
	public IntegrationFlow jmsIn(ConnectionFactory connectionFactory, MessageConverter messageConverter) {
	                 
	                return IntegrationFlows.from(Jms.messageDrivenChannelAdapter(connectionFactory)
	        				.jmsMessageConverter(messageConverter)
	        				.destination("price-queue")
	        				.errorChannel(IntegrationContextUtils.ERROR_CHANNEL_BEAN_NAME)
	        				)
	        				.transform(Transformers.fromJson(TradeInstrumentPrice.class))
	                        .handle(msg-> service.setInstrumentPrice((TradeInstrumentPrice)msg.getPayload()))
	                        .get();
	}

	@Bean
	public IntegrationFlow exceptionMessageFlow(MessageConverter messageConverter) {
		return IntegrationFlows.from(IntegrationContextUtils.ERROR_CHANNEL_BEAN_NAME).handle(msg -> {
			MessagingException exception = (MessagingException) msg.getPayload();
			throw exception;
		}).get();
	}


	
}
