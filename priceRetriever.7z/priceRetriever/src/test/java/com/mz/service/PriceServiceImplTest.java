package com.mz.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cache.CacheManager;
import org.springframework.jms.core.JmsTemplate;

import com.mz.PriceRetrieverApplication;
import com.mz.vo.TradeInstrumentPrice;

@SpringBootTest(classes = {PriceRetrieverApplication.class})
class PriceServiceImplTest {

	    @Autowired
	    private PriceServiceImpl priceService;
	    
	    @Autowired
	    private JmsTemplate jmsTemplate;
	    

		@Autowired
		CacheManager cacheManagerForVendors, cacheManagerForIns;
	
    
	    TradeInstrumentPrice i1 = new TradeInstrumentPrice("v1", "i1", LocalDate.now(),  new BigDecimal("100"));
	    TradeInstrumentPrice i2 = new TradeInstrumentPrice("v1", "i2", LocalDate.now().plusDays(30),new BigDecimal("200"));
	    TradeInstrumentPrice i3 = new TradeInstrumentPrice("v2", "i1", LocalDate.now().plusDays(10),new BigDecimal("2000"));

		
		private Set<TradeInstrumentPrice> getAllPrices() {
			return new HashSet<>(Arrays.asList(i1, i2, i3));
		}
		
	    @Test
	    public void testGetPriceByVendorId() {
	        getAllPrices().forEach(price -> priceService.setInstrumentPrice(price));
	        Set<TradeInstrumentPrice> prices = priceService.getPriceByVendor("v1");
	        assertFalse(prices.isEmpty());
	        assertEquals(2, prices.size());
	    }

	    @Test
	    public void testGetPriceByInstId() {
	        getAllPrices().forEach(price -> priceService.setInstrumentPrice(price));
	        Set<TradeInstrumentPrice> prices1 = priceService.getPriceByInst("i1");
	        assertFalse(prices1.isEmpty());
	        assertEquals(2, prices1.size());
	    }

	    @Test
	    public void testCache() {
	    	getAllPrices().forEach(price -> priceService.setInstrumentPrice(price));
	        Set<TradeInstrumentPrice> prices = priceService.getPriceByVendor("v1");
	        assertNotNull(cacheManagerForVendors.getCache("vendors").get("v1").get());
	        assertNotNull(cacheManagerForIns.getCache("ins").get("i1").get());

	    }
	    
	    @Test
	    public void testGetPriceByInvalidVendorId() {
	        getAllPrices().forEach(price -> priceService.setInstrumentPrice(price));
	        Set<TradeInstrumentPrice> prices = priceService.getPriceByVendor("v11");
	        assertTrue(prices.isEmpty());
	    }

	    @Test
	    public void testGetPriceByInvalidInstId() {
	        getAllPrices().forEach(price -> priceService.setInstrumentPrice(price));
	        Set<TradeInstrumentPrice> prices = priceService.getPriceByInst("i11");
	        assertTrue(prices.isEmpty());
	    }

	    
}