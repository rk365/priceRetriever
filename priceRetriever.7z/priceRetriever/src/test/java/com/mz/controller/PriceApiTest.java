package com.mz.controller;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.mz.PriceRetrieverApplication;
import com.mz.service.PriceServiceImpl;
import com.mz.vo.TradeInstrumentPrice;

@SpringBootTest(classes = { PriceRetrieverApplication.class, })
@AutoConfigureMockMvc
class PriceApiTest {

	@Autowired
	private MockMvc mockMvc;
	@Autowired
	private PriceServiceImpl priceService;

	public static TradeInstrumentPrice i1 = new TradeInstrumentPrice("v1", "i", LocalDate.now(), new BigDecimal("11"));
	Set<TradeInstrumentPrice> set1 = new HashSet<TradeInstrumentPrice>();

	@Test
	public void testGetPricesByVendorId() throws Exception {
		priceService.setInstrumentPrice(i1);
		mockMvc.perform(MockMvcRequestBuilders.get("/vendor/v1/prices", "v1").accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andExpect(jsonPath("$.[0].vendorId").value("v1"));
	}

	@Test
	public void testGetPricesByInsId() throws Exception {
		priceService.setInstrumentPrice(i1);
		mockMvc.perform(MockMvcRequestBuilders.get("/instrument/i/prices", "v1").accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andExpect(jsonPath("$.[0].instrumentId").value("i"));
	}
	
}
